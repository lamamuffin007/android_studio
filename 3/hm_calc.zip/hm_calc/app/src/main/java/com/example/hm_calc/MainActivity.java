package com.example.hm_calc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {

    //private TextInputLayout TIL1,TIL2;
    private TextInputEditText num_one,num_two;
    private TextView textView;
    Button button,button2,button3,button4;

    String oper = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

        num_one=(TextInputEditText)findViewById(R.id.num_one);
        num_two=(TextInputEditText)findViewById(R.id.num_two);
        //result
        textView=(TextView)findViewById(R.id.textView);

        button=(Button)findViewById(R.id.button);
        button.setOnClickListener((View.OnClickListener) this);

        button2=(Button)findViewById(R.id.button2);
        button2.setOnClickListener((View.OnClickListener) this);

        button3=(Button)findViewById(R.id.button3);
        button3.setOnClickListener((View.OnClickListener) this);

        button4=(Button)findViewById(R.id.button4);
        button4.setOnClickListener((View.OnClickListener) this);
    }

    @Override
    public void onClick(View view) {
        float num1 = 0;
        float num2 = 0;
        float res = 0;

        if (TextUtils.isEmpty(num_one.getText().toString()) || TextUtils.isEmpty(num_two.getText()))
        {return;}

        num1 = Float.parseFloat(num_one.getText().toString());
        num2 = Float.parseFloat(num_two.getText().toString());

        switch (view.getId()){
            case R.id.button:
                oper = "*";
                res = num1 * num2;
                break;
            case R.id.button2:
                oper = "+";
                res = num1 + num2;
                break;
            case  R.id.button3:
                oper = "-";
                res = num1 - num2;
                break;
            case R.id.button4:
                oper = "/";
                res = num1 / num2;
            default: break;
        }
        textView.setText(num1 + " " + oper + " "+num2+ " = "+res);
    }


}