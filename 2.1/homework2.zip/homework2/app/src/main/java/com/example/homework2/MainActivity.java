package com.example.homework2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView textView1, textView2;
    Button add,copy;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView1=(TextView)findViewById(R.id.textView);
        textView2=(TextView)findViewById(R.id.textView2);
        add=(Button)findViewById(R.id.add);
        copy=(Button)findViewById(R.id.button2);
    }
    public void onAdd(View view){
        String s1=textView1.getText().toString();
        String s2="*";
        textView1.setText(s1+s2);
    }

    public void onCopy(View view){
        String s=textView1.getText().toString();
        //String s3=textView2.getText().toString();
        textView2.setText(s);//+s3

    }

}